DROP TABLE IF EXISTS del_admin;
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Stock;
DROP TABLE IF EXISTS Product;
DROP TABLE IF EXISTS Address_Retailer;
DROP TABLE IF EXISTS Retailer;
DROP TABLE IF EXISTS Invoice;
DROP TABLE IF EXISTS Address_Customer;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Country;
DROP TABLE IF EXISTS Currency;
DROP TYPE IF EXISTS payment;
DROP TYPE IF EXISTS d_status;

SET client_encoding TO 'UTF-8';

CREATE TYPE payment as ENUM('COD','CREDIT CARD','DEBIT CARD','NETBANKING');

CREATE TYPE d_status as ENUM('SHIPPED','DELIVERED','CANCELLED','YET TO BE DISPACHED','OUT FOR DELIVERY');

CREATE TABLE Currency(
    id varchar(5) PRIMARY KEY,
    name varchar(30) NOT NULL,
    value_in_inr real NOT NULL
);

CREATE TABLE Country(
    id varchar(20) PRIMARY KEY,
    name varchar(100) NOT NULL,
    currency_id varchar(5) NOT NULL,
    CONSTRAINT FK_currency_id
    FOREIGN KEY(currency_id)
    REFERENCES Currency(id)
);

CREATE TABLE Product(
    id bigint PRIMARY KEY,
    name varchar NOT NULL
);


CREATE TABLE Customer(
    id bigint PRIMARY KEY,
    name varchar NOT NULL,
    email_id varchar(320) NOT NULL,
    country_id varchar(20) NOT NULL,
    mobile_number varchar(15) NOT NULL,
    passwrd varchar(50) NOT NULL,
    CONSTRAINT FK_country_id
    FOREIGN KEY(country_id)
    REFERENCES Country(id)
);


CREATE TABLE Address_Customer (
    id varchar PRIMARY KEY,
    customer_id bigint NOT NULL,
    pincode int NOT NULL,
    city varchar(85) NOT NULL,
    state_name varchar(50) NOT NULL,
    house_address varchar(200) NOT NULL,
    CONSTRAINT FK_customer_id
    FOREIGN KEY(customer_id)
    REFERENCES Customer(id)
) ;


CREATE TABLE Retailer(
    id bigint PRIMARY KEY,
    name varchar NOT NULL,
    email_id varchar(320) NOT NULL,
    country_id varchar(20) NOT NULL,
    mobile_number varchar(15) NOT NULL,
    passwrd varchar(50) NOT NULL,
    CONSTRAINT FK_country_id
    FOREIGN KEY(country_id)
    REFERENCES Country(id)
);


CREATE TABLE Address_Retailer (
    id varchar PRIMARY KEY,
    retailer_id bigint NOT NULL,
    pincode int NOT NULL,
    city varchar(85) NOT NULL,
    state_name varchar(50) NOT NULL,
    store_name varchar(200) NOT NULL,
    CONSTRAINT FK_retailer_id
    FOREIGN KEY(retailer_id)
    REFERENCES Retailer(id)
) ;

CREATE TABLE Stock(
    retailer_id bigint,
    product_id bigint,
    price real NOT NULL,
    quantity int NOT NULL,
    PRIMARY KEY(retailer_id, product_id),
    CONSTRAINT FK_retailer_id
    FOREIGN KEY(retailer_id)
    REFERENCES Retailer(id),
    CONSTRAINT FK_product_id
    FOREIGN KEY(product_id)
    REFERENCES Product(id)
);


CREATE TABLE Invoice (
    invoice_no varchar(20) PRIMARY KEY,
    date_time timestamp NOT NULL,
    customer_id bigint NOT NULL,
    payment_method payment NOT NULL,
    customer_address varchar NOT NULL,
    CONSTRAINT FK_customer_id
    FOREIGN KEY(customer_id)
    REFERENCES Customer(id),
    CONSTRAINT FK_customer_address
    FOREIGN KEY(customer_address)
    REFERENCES Address_Customer(id)
) ;

CREATE TABLE Orders (
    invoice_no varchar(20),
    product_id bigint,
    quantity int NOT NULL,
    retailer_id bigint,
    delivery_status d_status NOT NULL,
    retailer_address varchar,
    PRIMARY KEY (invoice_no,product_id,retailer_id,retailer_address),
    CONSTRAINT FK_invoice_no
    FOREIGN KEY (invoice_no)
    REFERENCES Invoice(invoice_no),
    CONSTRAINT FK_product_id
    FOREIGN KEY (product_id)
    REFERENCES Product(id),
    CONSTRAINT FK_retailer_id
    FOREIGN KEY(retailer_id)
    REFERENCES Retailer(id),
    CONSTRAINT FK_retailer_address
    FOREIGN KEY (retailer_address)
    REFERENCES Address_Retailer(id)
) ;

CREATE TABLE Del_Admin(
    id bigint PRIMARY KEY,
    name varchar NOT NULL,
    email_id varchar(320) NOT NULL,
    country_id varchar(20) NOT NULL,
    mobile_number varchar(15) NOT NULL,
    passwrd varchar(50) NOT NULL,
    CONSTRAINT FK_country_id
    FOREIGN KEY(country_id)
    REFERENCES Country(id)
);
