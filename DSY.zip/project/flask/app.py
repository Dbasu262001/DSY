import os
import psycopg2
from flask import Flask,render_template,request,redirect

app = Flask(__name__)

bag_array = []
customer_object = []
# 0 for id, 1 for name, 2 for mail, 3 for country id, 4 for mobile 
customer_display = []
customer_addresses = []

def connect_customer():
    conn = psycopg2.connect(
        host = 'localhost',
        database = 'dsy',
        user = 'customer',
        password='nopass'
    )
    return conn

def connect_retailer():
    conn = psycopg2.connect(
        host = 'localhost',
        database = 'dsy',
        user = 'retailer',
        password='nopass'
    )
    return conn

def connect_delivery():
    conn = psycopg2.connect(
        host = 'localhost',
        database = 'dsy',
        user = ' delivery_administrator',
        password='nopass'
    )
    return conn

def logoutUser():
    return render('index.html')

@app.route('/')
def index():
    return render_template("index.html");

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/signup', methods = ['POST'])
def sign_up():
    name = request.form.get('name')
    email = request.form.get('email_id')
    mobile_no = request.form.get('mobile')
    country = request.form.get('country')
    state = request.form.get('state') 
    pincode = request.form.get('pincode')
    password = request.form.get('passwrd')
    city = request.form.get('city')
    address = request.form.get('address')
    conn = connect_customer()
    cur=conn.cursor()
    cur.execute("select count(*) from customer;");
    dat = cur.fetchall();
    id = dat[0][0]
    query = 'BEGIN TRANSACTION;\n\n'

    query = query + "INSERT INTO customer VALUES("+ str(id) +",\'"+ name +"\',\'"+email+"\',\'" + "IND"+ "\',\'" + str(mobile_no)+ "\',\'" + password+ "\');\n"

    query=query+"INSERT INTO address_customer VALUES(\'c_"+str(id)+"\',"+str(id)+","+str(pincode)+",\'"+state+"\',\'"+city+"\',\'"+address+"\');\n\n"

    query=query+"END TRANSACTION;"
    cur.execute(query)
    cur.close()
    conn.close()
    return index()

@app.route('/customerLogin',methods=['POST','GET'])
def customerLoginUser():
    if request.method=='POST':
        email = request.form['emailID']
        password = request.form['password']
        
        conn = connect_customer() 
        curr = conn.cursor()
        curr.execute('SELECT * FROM customer WHERE email_id= \'{}\';'.format(email))
        data = curr.fetchall()
        curr.close()
        conn.close()
        if(len(data)==0):
            return render_template('index.html')
        if(data[0][5]==password): 
            global customer_object
            customer_object.clear()
            i = 0
            for i in range(5):
                customer_object.append(data[0][i])
            
            return redirect('/customer')
    return render_template('customerLogin.html')

@app.route('/retailerLogin',methods=['POST','GET'])
def retailerLoginUser():
    if request.method=='POST':
        email = request.form['emailID']
        password = request.form['password']
        
        conn = connect_customer()
        cur = conn.cursor()

        cur.execute('SELECT passwrd FROM retailer WHERE email_id= \'{}\';'.format(email))
        data = cur.fetchall()
        cur.close()
        conn.close()
        if(len(data)==0):
            return render_template('index.html')
        elif(data[0][0]==password):
            return redirect('/retailer')
    return render_template('retailerLogin.html')

@app.route('/retailerLogin',methods=['POST','GET'])
def delivererLoginUser():
    if request.method=='POST':
        email = request.form['emailID']
        password = request.form['password']
        
        conn = connect_customer()
        cur = conn.cursor()

        cur.execute('SELECT passwrd FROM del_admin WHERE email_id= \'{}\';'.format(email))
        data = cur.fetchall()
        cur.close()
        conn.close()
        if(len(data)==0):
            return render_template('index.html')
        if(data[0][0]==password):
            return redirect('/deliverer')
    return render_template('delivererLogin.html')

@app.route('/customer')
def customer(): 
    conn = connect_customer()
    cur = conn.cursor()
    cur.execute('SELECT * FROM product limit 200;')
    global customer_display
    customer_display = cur.fetchall()
    cur.close()
    conn.close() 
    return render_template('customer.html',tuples=customer_display)

@app.route('/retailer')
def retailer():
    return render_template('retailer.html')

@app.route('/deliverer')
def deliverer():
    return render_template('deliverer.html')


@app.route('/orders')
def orders():
    conn = connect_customer()
    cur = conn.cursor()
    cur.execute('select invoice_no,product_id,quantity,retailer_id,delivery_status,retailer_address from orders inner join (select invoice_no as iid from invoice where customer_id = \'{}\') as t ON orders.invoice_no=t.iid;'.format(customer_object[0]))
    data = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('orders.html', arr = data)

    
@app.route('/profile')
def profile():
    return render_template('profile.html', data = customer_object)

@app.route('/bag')
def bag():
    return render_template('bag.html', bag_array = bag_array)

def num_len(num):
    ans=0
    a = num
    while(a>0):
        a=a//10
        ans+=1
    s='N'
    for i in range(18-ans):
        s=s+'0'
    s=s+str(num)
    return s

@app.route('/bag', methods = ['POST'])
def place_order():
    print("order placed")
    arr = []
    global bag_array
    for tuple in bag_array:
        quantity = int(request.form.get(str(tuple[3])))
        bag_array[tuple[3]][1] = quantity
    
    conn = connect_customer()
    cur = conn.cursor()
    query ='BEGIN TRANSACTION;\n\n'
    cur.execute('SELECT count(*) FROM invoice where invoice_no like \'N%\';')
    dat = cur.fetchall()
    num = dat[0][0]
    cur.execute('SELECT CURRENT_TIMESTAMP(0)::TIMESTAMP WITHOUT TIME ZONE;')
    tim = cur.fetchall()
    tim=tim[0][0]
    query=query+"INSERT INTO invoice VALUES(\'" + num_len(num) + "\', \'"+ str(tim) +"\', "+str(customer_object[0])+" , \'COD\', \'c_"+str(customer_object[0]) +"\');\n\n"
    for b in bag_array:
        query=query+"INSERT INTO orders VALUES(\'" + num_len(num)+ "\',"+  str(b[0])+ ", "+ str(b[1])+ ", "+ str(b[5]) + ", \'YET TO BE DISPACHED\', "+'\'r_'+str(b[5]) + "\') ;\n"
        query=query+"UPDATE stock SET quantity =" +str(b[6]-b[1]) +" where retailer_id= "+ str(b[5]) +" and product_id = "+str(b[0])+";\n\n"

    query=query+"END TRANSACTION;"
    print(query)
    cur.execute(query)
    cur.close()
    conn.close()
    bag_array.clear()
    print(arr)
    return customer()


# contents of bag array tuple
# 0 - pid, 1 - quantity, 2 - p_name, 3 - index, 4 - price, 5 - retailer_id 6- retailer_quantity
@app.route('/customer', methods = ['POST'])
def addToBag(): 
    p = request.form.get('p_search')
    if(p != None):
        conn = connect_customer()
        cur = conn.cursor()
        cur.execute('SELECT * FROM product WHERE name LIKE \'{}%\' limit 200;'.format(p))
        global customer_display
        customer_display.clear()
        customer_display = cur.fetchall()
        cur.close()
        conn.close()
        return render_template('customer.html',tuples=customer_display)
    
    p = (request.form.get('addtobag'))
    if(p != None): 
        t = []
        p = int(p)
        t.append(p)
        t.append(1)
        conn = connect_customer()
        cur = conn.cursor()
        cur.execute('SELECT name FROM product WHERE id= \'{}\';'.format(p))
        data = cur.fetchall()
        cur.close()
        conn.close()
        t.append(data[0][0])
        global bag_array
        t.append(len(bag_array))
        insert = True
        for y in bag_array:
            if(y[0] == p):
                insert = False
                break
        
        if(insert):
            conn = connect_customer()
            cur = conn.cursor()
            cur.execute('SELECT t.id,t.name,t.price,t.quantity,t.product_id, pincode,city, state_name,store_name FROM address_retailer INNER JOIN (SELECT retailer.id, retailer.name,tbl.price,tbl.quantity,tbl.product_id FROM retailer inner join (SELECT * FROM stock WHERE product_id = {} ORDER BY price ASC LIMIT 1) AS tbl ON retailer.id = tbl.retailer_id) as t ON address_retailer.retailer_id = t.id;'.format(p))
            data = cur.fetchall()
            cur.close()
            conn.close()
            t.append(data[0][2])
            t.append(data[0][0])
            t.append(data[0][3])
            bag_array.append(t) 
            
    return render_template('customer.html',tuples=customer_display)

# contents of bag array tuple
# 0 - pid, 1 - quantity, 2 - p_name, 3 - index, 4 - price, 5 - retailer_id
# indexes :
# sorted_products