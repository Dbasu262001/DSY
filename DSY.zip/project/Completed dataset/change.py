import pandas as pd

old = pd.read_csv("Retailer.csv")
old['password']='nopass'
old.to_csv('nRetailer.csv',index=False)
print(old)