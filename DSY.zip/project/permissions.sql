-- Revoke all permissons from public
REVOKE ALL ON DATABASE dsy FROM public;

--Grant permission to customers to connect ot dsy database
GRANT CONNECT ON DATABASE dsy TO customer;

--Grant permission to retailers to connect ot dsy database
GRANT CONNECT ON DATABASE dsy TO retailer;

--Grant permission to delievery_administrator to connect ot dsy database
GRANT CONNECT ON DATABASE dsy TO delivery_administrator;

--Revoke all permissions from public schema
REVOKE CREATE ON SCHEMA public FROM public;

--To check permissions on tables
--SELECT grantee, privilege_type FROM information_schema.role_table_grants WHERE table_name='orders';

--Grant permissions to customer on tables
GRANT INSERT, DELETE, SELECT, UPDATE ON TABLE customer TO customer;
GRANT INSERT, DELETE, SELECT, UPDATE ON TABLE address_customer TO customer;
GRANT INSERT, DELETE, SELECT, UPDATE(payment_method) ON TABLE invoice TO customer;
GRANT INSERT, DELETE, SELECT, UPDATE(delivery_status) ON TABLE orders TO customer;
GRANT SELECT, UPDATE(quantity) ON TABLE stock TO customer;
GRANT SELECT ON TABLE retailer TO customer;
GRANT SELECT ON TABLE address_retailer TO customer;
GRANT SELECT ON TABLE country TO customer;
GRANT SELECT ON TABLE currency TO customer;
GRANT SELECT ON TABLE product TO customer;

--Grant permission to retailer on tables
GRANT INSERT,DELETE,UPDATE,SELECT ON TABLE retailer TO retailer;
GRANT INSERT,DELETE,UPDATE,SELECT ON TABLE address_retailer TO retailer;
GRANT INSERT,DELETE,UPDATE(price,quantity),SELECT ON TABLE stock TO retailer;
GRANT INSERT,SELECT ON TABLE product TO retailer;
GRANT UPDATE(delivery_status),SELECT ON TABLE orders TO retailer;
GRANT SELECT ON TABLE country TO retailer;
GRANT SELECT ON TABLE currency TO retailer;

--Grant permission to delivery_administrator on tables
GRANT SELECT ON TABLE orders TO delivery_administrator;
GRANT INSERT,DELETE,SELECT,UPDATE ON TABLE del_admin TO delivery_administrator;
GRANT UPDATE(delivery_status) ON TABLE orders TO delivery_administrator;