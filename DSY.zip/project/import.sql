BEGIN TRANSACTION;

COPY Currency FROM 'D:/project/Completed dataset/Currency.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Country FROM 'D:/project/Completed dataset/Country.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Product FROM 'D:/project/Completed dataset/Product.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Customer FROM 'D:/project/Completed dataset/Customer.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Address_Customer FROM 'D:/project/Completed dataset/Address_Customer.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Retailer FROM 'D:/project/Completed dataset/Retailer.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Address_Retailer FROM 'D:/project/Completed dataset/Address_Retailer.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Stock FROM 'D:/project/Completed dataset/Stock.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Invoice FROM 'D:/project/Completed dataset/Invoice.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Orders FROM 'D:/project/Completed dataset/Orders.csv' WITH CSV HEADER DELIMITER AS ',';
COPY Del_Admin FROM 'D:/project/Completed dataset/delivery_admin.csv' WITH CSV HEADER DELIMITER AS ',';

END TRANSACTION;